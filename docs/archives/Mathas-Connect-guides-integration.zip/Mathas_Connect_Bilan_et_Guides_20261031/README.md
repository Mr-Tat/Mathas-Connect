# Bilan et guides des prochaines intégrations Math’as Connect

Dossier documentaire du 31 octobre 2026. Mélange est déjà publié et ouvert : aucune migration ni ouverture n'est à recommencer.

## Pour le propriétaire

1. Lire le [bilan de l’intégration](docs/BILAN_CALCULS_MELANGES_20261031.md).
2. Joindre ce ZIP à la prochaine discussion Codex.
3. Copier le message général de [PROMPTS_PROCHAINES_INTEGRATIONS_CONNECT.md](docs/PROMPTS_PROCHAINES_INTEGRATIONS_CONNECT.md), compléter le nom/périmètre, puis ajouter le complément Multiplication ou futur Mélange.

## Pour la prochaine discussion Codex

Lire d’abord [le passage de flambeau](docs/PASSAGE_DE_FLAMBEAU_INTEGRATIONS_CONNECT_20261031.md), puis le guide général et la fiche correspondant à l’application. Ce dossier décrit une méthode et des faits datés ; les instructions actuelles du propriétaire restent prioritaires.

Les liens de code des copies portables pointent vers le main applicatif de référence. Les liens internes entre les cinq nouveaux guides fonctionnent dans le ZIP.

- Main applicatif étudié : `4aea80e3db824e74c2e13f529b14c871e8435269`.
- Branche documentaire : `docs/bilan-et-guides-integrations-20261031`.
- Commit documentaire : `2772a82c57386a3b2b60829bcef54f4010f20a01`.
- [Documents sur GitHub](https://github.com/Mr-Tat/Mathas-Connect/tree/docs/bilan-et-guides-integrations-20261031/docs).

Cette branche n'est pas fusionnée à main. Aucun code applicatif, SQL, paramètre de production ou résultat élève n'a été modifié pour préparer le dossier. Le ZIP ne contient aucun script de déploiement, secret ou résultat d’élève.

Le repérage de Multiplication-multi est une lecture du code à un HEAD précis, pas une intégration déjà réalisée ni une validation pédagogique de son futur barème.
