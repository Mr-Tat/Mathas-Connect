import {summarizeProjection} from './projection-model.mjs';
import {classId as requestedClassId} from './connect-context.js';

// Vue professeur uniquement. Lecture de résumés existants, jamais d'écriture serveur.
const endpoint='https://awmhpfofacaglewammxt.supabase.co';
const publicKey='sb_publishable_oI2Pyl3kXzmLkK-CBnw9Nw_66a4fZgM';
const $=id=>document.getElementById(id);
let client,catalog=[],generation=0,loading=false,accessRevoked=false,currentAggregate=null,period='recent';

function note(message){$('status').textContent=message}
function clearBoard(message='Chiffres masqués. Clique sur « Afficher / Actualiser » pour les consulter.'){
 generation++;
 currentAggregate=null; // Un masquage efface aussi la copie anonyme en mémoire.
 $('board').hidden=true;
 $('blank').hidden=false;
 $('blank').firstElementChild.textContent=message;
 for(const id of ['total','participants','today','class-name','updated'])$(id).textContent='';
 $('apps').replaceChildren();
 note(message);
}
function loginRequired(message){
 clearBoard(message);
 $('controls').hidden=true;
 $('login-needed').hidden=false;
}
async function api(functionName,action,data={}){
 const {data:{session},error}=await client.auth.getSession();
 if(error||!session?.access_token||session.user?.is_anonymous)throw Error('Connexion professeur requise.');
 // Une connexion instable ne doit jamais bloquer indéfiniment l'écran de classe.
 const watchdog=new AbortController();
 const deadline=setTimeout(()=>watchdog.abort(),12000);
 try{
  const response=await fetch(endpoint+'/functions/v1/'+functionName,{
   method:'POST',cache:'no-store',signal:watchdog.signal,
   headers:{apikey:publicKey,authorization:'Bearer '+session.access_token,'content-type':'application/json'},
   body:JSON.stringify({action,...data})
  });
  const result=await response.json().catch(()=>({}));
  if(!response.ok||result.ok!==true)throw Error(result.error==='forbidden'?'Accès professeur refusé.':result.error||'Données indisponibles.');
  return result;
 }catch(error){
  if(watchdog.signal.aborted)throw Error('Connexion trop lente : réessaie avec le bouton Actualiser.');
  throw error;
 }finally{clearTimeout(deadline)}
}
function metric(id,value){$(id).textContent=String(value)}
function renderBars(){
 const data=currentAggregate;
 const apps=$('apps');apps.replaceChildren();
 if(!data)return;
 const isToday=period==='today';
 $('period-recent').setAttribute('aria-pressed',String(!isToday));
 $('period-today').setAttribute('aria-pressed',String(isToday));
 $('period-help').textContent=isToday
  ?'Élèves ayant joué aujourd’hui, selon les trois dernières parties conservées par application. Les parties plus anciennes ne sont pas comptabilisées.'
  :'Élèves ayant une partie dans les trois dernières parties disponibles par application. Ce n’est pas un décompte de toutes les parties historiques.';
 if(!data.apps.length){
  const p=document.createElement('p');p.textContent='Aucune application publique dans cette première version.';apps.append(p);
 }
 for(const app of data.apps){
  const count=isToday?app.today:app.recent;
  const row=document.createElement('div');row.className='app-row';
  const name=document.createElement('strong');name.textContent=app.title;
  const track=document.createElement('div');track.className='track';
  track.setAttribute('role','progressbar');
  track.setAttribute('aria-label',(isToday?'Participation aujourd’hui : ':'Historique récent : ')+app.title);
  track.setAttribute('aria-valuemin','0');track.setAttribute('aria-valuemax',String(data.total));
  track.setAttribute('aria-valuenow',String(count));
  const fill=document.createElement('div');fill.className='fill';
  fill.style.width=(data.total?Math.round(100*count/data.total):0)+'%';
  track.append(fill);
  const amount=document.createElement('output');amount.textContent=count+' / '+data.total;
  row.append(name,track,amount);apps.append(row);
 }
}
function render(data,classLabel){
 $('class-name').textContent=classLabel;
 $('updated').textContent='Actualisé à '+new Intl.DateTimeFormat('fr-BE',{hour:'2-digit',minute:'2-digit'}).format(new Date());
 metric('total',data.total);
 metric('participants',data.participants);
 metric('today',data.activeToday);
 currentAggregate=data; // Aucun nom ni résultat individuel dans cet objet.
 renderBars();
 $('blank').hidden=true;
 $('board').hidden=false;
 note('Tableau collectif affiché · lecture seule · actualisation manuelle.');
}
async function refresh(){
 if(loading)return;
 const classId=$('class-choice').value;
 if(!classId)return note('Choisis une classe.');
 const label=$('class-choice').selectedOptions[0]?.textContent||'Classe';
 const ticket=++generation;
 loading=true;$('load').disabled=true;
 note('Chargement du résumé collectif…');
 try{
  const results=await api('connect-results','teacher-overview',{classId});
  if(accessRevoked||ticket!==generation||$('class-choice').value!==classId)return;
  const aggregate=summarizeProjection(results.students,catalog,new Date());
  render(aggregate,label);
 }catch(error){
  if(ticket!==generation)return;
  clearBoard('Impossible de charger le tableau collectif.');
  note('Erreur : '+(error?.message||'Réseau indisponible.'));
 }finally{
  loading=false;$('load').disabled=false;
 }
}
async function initialize(){
 try{
  const {createClient}=await import('https://esm.sh/@supabase/supabase-js@2.95.0');
  client=createClient(endpoint,publicKey,{auth:{
   persistSession:true,autoRefreshToken:true,detectSessionInUrl:false,
   storageKey:'mathas-connect-professor-auth-v1'
  }});
  // Une fermeture de session depuis l'autre onglet doit masquer immédiatement
  // les statistiques déjà projetées, même sans actualisation manuelle.
  client.auth.onAuthStateChange((event)=>{
   if(event==='SIGNED_OUT'||event==='USER_DELETED'){
    accessRevoked=true;
    loginRequired('Session professeur terminée. Reconnecte-toi pour continuer.');
   }
  });
  const {data:{session}}=await client.auth.getSession();
  if(!session?.access_token||session.user?.is_anonymous){
   loginRequired('Connecte-toi d’abord à l’espace professeur.');
   return;
  }
  // Une lecture de classes lors de l'ouverture ; aucune requête périodique.
  const [dashboard,response]=await Promise.all([
   api('connect-api','teacher-dashboard'),
   fetch('./hub-catalog.json',{cache:'no-store'})
  ]);
  if(!response.ok)throw Error('Catalogue indisponible.');
  const config=await response.json();
  if(accessRevoked)return; // La connexion a pu être fermée pendant le chargement.
  catalog=Array.isArray(config.apps)?config.apps:[];
  const classes=(Array.isArray(dashboard.classes)?dashboard.classes:[])
   .filter(c=>c?.id&&typeof c.name==='string'&&!c.name.includes('TEST'));
  const select=$('class-choice');
  select.replaceChildren(new Option('Choisir une classe',''),
   ...classes.map(c=>new Option(c.name,c.id)));
  // Les quatre boutons Projection du professeur présélectionnent leur classe.
  // L'identifiant URL ne donne aucun droit et ne déclenche aucune lecture de résultats.
  if(requestedClassId&&classes.some(c=>c.id===requestedClassId))select.value=requestedClassId;
  $('login-needed').hidden=true;
  $('controls').hidden=false;
  clearBoard(classes.length?'Sélectionne une classe et lance l’affichage collectif.':'Aucune classe disponible pour cette connexion professeur.');
 }catch(error){
  loginRequired('Accès impossible : '+(error?.message||'Erreur réseau')+'. Ouvre l’espace professeur et réessaie.');
 }
}
$('period-recent').addEventListener('click',()=>{period='recent';renderBars()});
$('period-today').addEventListener('click',()=>{period='today';renderBars()});
$('class-choice').addEventListener('change',()=>clearBoard('Classe changée : le tableau précédent a été effacé.'));
$('load').addEventListener('click',refresh);
$('hide').addEventListener('click',()=>clearBoard());
$('fullscreen').addEventListener('click',async()=>{
 try{
  if(document.fullscreenElement)await document.exitFullscreen();
  else await document.documentElement.requestFullscreen();
 }catch{note('Le mode plein écran n’est pas disponible dans ce navigateur.')}
});
window.addEventListener('pagehide',()=>clearBoard('Tableau masqué après fermeture de la page.'));
initialize();
