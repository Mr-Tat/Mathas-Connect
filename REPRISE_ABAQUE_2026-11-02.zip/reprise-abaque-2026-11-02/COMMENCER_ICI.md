# Reprendre le travail Abaque dans une nouvelle conversation

Dossier préparé le 2 novembre 2026, après vérification des branches et de la CI. Il contient le contexte, le prompt de reprise et les sources exactes. Aucun compte ni résultat d’élève n’est exporté ; aucun jeton d’accès n’est fourni.

1. Ouvre une nouvelle conversation ChatGPT, de préférence avec accès aux dépôts GitHub et à l’environnement de développement.
2. Joins l’archive complète `REPRISE_ABAQUE_2026-11-02.zip`.
3. Copie le contenu de `PROMPT_A_COLLER.md` dans ton message. Si tu ne peux joindre qu’un document texte, joins `PASSAGE_DE_RELAIS.md`, qui contient l’essentiel.

Les fichiers à lire d’abord sont `PASSAGE_DE_RELAIS.md`, puis `ETAT_TECHNIQUE.json`. Les sources sont dans `sources/` et les écarts Git dans `patches/`. Les deux dépôts restent distincts.

Attention au point nouveau constaté pendant cette préparation : le candidat Abaque testé est `38bc882`, mais le main Connect a avancé jusqu’à `d148b43` avec des changements dans le Laboratoire et le HUB. Il faut rapprocher ces versions avant une publication. La CI verte de `38bc882` ne valide pas une fusion future.

L’application autonome et la démo sont déjà publiées. Le pilote Abaque réellement connecté n’a pas été déployé par cette mission. Le blocage confirmé dans cet environnement est l’absence de binding Supabase et la configuration réseau non appliquée. Les droits peuvent être différents dans la nouvelle conversation : l’agent doit les vérifier.

Le brouillon cloud préparé dans l’ancienne conversation n’est pas automatiquement attaché à une nouvelle. Le secret doit être fourni uniquement dans les paramètres sécurisés de l’environnement concerné, puis la configuration enregistrée/publiée. Ne transmets aucun jeton dans le message ou l’archive.

Les captures dans `visuels/` montrent des simulations de test. Elles n’attestent aucune connexion hébergée. Le prompt initial est conservé dans `historique/` ; les décisions plus récentes du passage de relais priment, notamment six coupes au lieu de trois et le dépôt autonome comme source de référence.

Les instantanés dans `sources/` contiennent les fichiers suivis par Git à trois commits : autonome, candidat Connect et main Connect constaté. Ils n’incluent ni historique `.git`, ni dépendances installées, ni secrets d’environnement. Les liens GitHub et les SHA permettent de retrouver les branches réelles. Le script de setup est une référence pour un environnement équivalent ; adapter ses chemins si nécessaire.

La présente livraison ne fusionne aucune branche et ne modifie aucun SQL, Edge ou site publié. Les empreintes de `CHECKSUMS.sha256` permettent de vérifier les fichiers du dossier.
