#!/usr/bin/env bash
set -euo pipefail
tools_dir=/workspace/.cloud-tools
mkdir -p "$tools_dir"
if ! test -x "$tools_dir/node_modules/node/bin/node" || ! "$tools_dir/node_modules/node/bin/node" - "$tools_dir" <<'JS'
const root=process.argv[2];
if(process.version!=='v22.22.0')process.exit(1);
try{for(const [name,version] of Object.entries({playwright:'1.57.0',pg:'8.16.3',esbuild:'0.27.2','@supabase/supabase-js':'2.95.0'}))if(require(root+'/node_modules/'+name+'/package.json').version!==version)process.exit(1);}catch{process.exit(1);}
JS
then
 npm install --prefix "$tools_dir" --no-save --no-package-lock node@22.22.0 playwright@1.57.0 pg@8.16.3 esbuild@0.27.2 @supabase/supabase-js@2.95.0
fi
if ! test -e /workspace/node_modules; then ln -s "$tools_dir/node_modules" /workspace/node_modules; fi
export PATH="$tools_dir/node_modules/node/bin:$PATH"
node --version
node -e "require('/workspace/node_modules/playwright');require('/workspace/node_modules/pg');require('/workspace/node_modules/esbuild');require('/workspace/node_modules/@supabase/supabase-js')"
# Official CLI for authorized metadata checks and targeted deployment.
supabase_cli="$tools_dir/supabase-cli/node_modules/.bin/supabase"
if ! test -x "$supabase_cli" || [ "$("$supabase_cli" --version 2>/dev/null)" != 3.0.0 ]; then
 npm install --prefix "$tools_dir/supabase-cli" --no-save --no-package-lock supabase@3.0.0
fi
"$supabase_cli" --version
test -x /usr/bin/chromium
python3 --version
# Optional legacy Soustraction/PostgreSQL browser test needs the bundled shell.
# Abaque and the representative browser suites use the installed system Chromium.
if [ "${MATHAS_TEST_BUNDLED_CHROMIUM:-0}" = 1 ]; then
 PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT=20000 node "$tools_dir/node_modules/playwright/cli.js" install chromium --only-shell
fi
docker_local(){ env -u DOCKER_HOST -u DOCKER_CONTEXT -u DOCKER_TLS -u DOCKER_TLS_VERIFY -u DOCKER_CERT_PATH docker --host=unix:///var/run/docker.sock "$@"; }
docker_local info >/dev/null
# Verified official images used by the disposable database/Auth/Edge fixtures.
ABAQUE_POSTGRES_IMAGE='postgres:17@sha256:3b0cda93be7c8dba2ed484d19393d93845dc3dafb88973e248ba8e6d99d784e1'
ABAQUE_AUTH_IMAGE='supabase/gotrue:v2.186.0@sha256:f2112b9289422f205df4ea15b8b550d425ae42528ea54521faa32cc7b62490de'
ABAQUE_REST_IMAGE='postgrest/postgrest:v14.3@sha256:7c5840727ad683b0fdbfb9810930665b34f8b44884a4dc740aa8844748a2b85e'
ABAQUE_EDGE_IMAGE='supabase/edge-runtime:v1.70.0@sha256:d5b0545da7826404668c3a53809f217a9c7093526c7036c18e79ddc61e4cbe01'
ABAQUE_GATEWAY_IMAGE='kong:2.8.1@sha256:1b53405d8680a09d6f44494b7990bf7da2ea43f84a258c59717d4539abf09f6d'
for image in "$ABAQUE_POSTGRES_IMAGE" "$ABAQUE_AUTH_IMAGE" "$ABAQUE_REST_IMAGE" "$ABAQUE_EDGE_IMAGE" "$ABAQUE_GATEWAY_IMAGE"; do
 docker_local image inspect "$image" >/dev/null 2>&1 || docker_local pull "$image" >/dev/null
done
